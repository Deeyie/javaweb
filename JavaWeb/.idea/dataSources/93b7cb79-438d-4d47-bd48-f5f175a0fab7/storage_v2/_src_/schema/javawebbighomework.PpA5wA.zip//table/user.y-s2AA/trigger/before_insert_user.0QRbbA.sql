create definer = root@localhost trigger before_insert_user
    before insert
    on user
    for each row
BEGIN
    DECLARE count INT;
    SELECT COUNT(*) INTO count FROM user WHERE phone_number = NEW.phone_number;
    IF count >= 3 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only two accounts can be registered with the same mobile phone number!';
    END IF;
END;

